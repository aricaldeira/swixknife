

from .spellout import sezimal_spellout
