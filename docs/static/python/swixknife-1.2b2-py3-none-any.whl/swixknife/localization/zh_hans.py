

__all__ = ('SezimalLocaleZH_HANS',)


from .zh import SezimalLocaleZH


class SezimalLocaleZH_HANS(SezimalLocaleZH):
    pass
