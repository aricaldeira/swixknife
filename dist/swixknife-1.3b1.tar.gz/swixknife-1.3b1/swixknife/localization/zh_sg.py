

__all__ = ('SezimalLocaleZH_SG',)


from .zh import SezimalLocaleZH


class SezimalLocaleZH_SG(SezimalLocaleZH):
    DEFAULT_TIME_ZONE = 'Asia/Singapore'
