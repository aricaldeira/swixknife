

__all__ = ('SezimalLocaleZH_CN',)


from .zh import SezimalLocaleZH


class SezimalLocaleZH_CN(SezimalLocaleZH):
    DEFAULT_TIME_ZONE = 'Asia/Shanghai'

